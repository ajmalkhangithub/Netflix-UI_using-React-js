import React, { useEffect, useState } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import './Player.css'
import back_arrow_icon from '../../Assets/back_arrow_icon.png'

const Player = () => {
  const { movieId } = useParams()   // get movieId from route
  const navigate = useNavigate()

  const [apiData, setApiData] = useState({
    name: "",
    key: "",
    published_at: "",
    type: ""
  })

  const options = {
    method: 'GET',
    headers: {
      accept: 'application/json',
      Authorization: 'Bearer YOUR_API_TOKEN'
    }
  }

  useEffect(() => {
    if (!movieId) return
    fetch(`https://api.themoviedb.org/3/movie/${movieId}/videos?language=en-US`, options)
      .then(res => res.json())
      .then(res => {
        if (res.results && res.results.length > 0) {
          setApiData(res.results[0]) // first trailer
        }
      })
      .catch(err => console.error(err))
  }, [movieId])

  return (
    <div className='player'>
      {/* Back button */}
      <img src={back_arrow_icon} alt="Back" onClick={() => navigate(-1)} />

      {/* Trailer video */}
      <iframe
        src={`https://www.youtube.com/embed/${apiData.key}`}
        frameBorder="0"
        width="90%"
        height="90%"
        title="trailer"
        allowFullScreen
      ></iframe>

      {/* Info */}
      <div className="player-info">
        <p>{apiData.published_at.slice(0,10)}</p>
        <p>{apiData.name}</p>
        <p>{apiData.type}</p>
      </div>
    </div>
  )
}

export default Player
