import React, { useState } from 'react'
import './Home.css'
import Navbar from '../../components/Navbar/Navbar'
import hero_banner from '../../Assets/hero_banner.jpg'
import hero_title from '../../Assets/hero_title.png'
import play_icon from '../../Assets/play_icon.png'
import info_icon from '../../Assets/info_icon.png'
import TitleCards from '../../components/TitleCards/TitleCards'
import Footer from '../../components/Footer/Footer'
// import Contact from '../Contact/Contact'
const Home = () => {

  return (
    <div className='home'>
      <Navbar/>
      <div className="hero">
        <img src={hero_banner} alt="" className='banner-img'/>
        <div className="hero-caption">
          <img src={hero_title} alt="" className='caption-img' />
          <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Impedit nostrum quisquam voluptates placeat dolorum ab iste! Animi esse et sequi.</p>
          <div className="hero-btns">
            <button className='btn'><img src={play_icon} alt="" />Play</button>
            <button className='btn dark-btn'><img src={info_icon} alt="" />More Info</button>
          </div>
          <TitleCards className='title-cards'/>
        </div>
      </div>
      {/* <Contact/> */}
      <div className="more-cards">
         <TitleCards title={'Blockbuster Moveis'} category={"top_rated"}/>
          <TitleCards title={'Only on Netflix'} category={"popular"}/>
           <TitleCards title={'Upcoming'} category={"upcoming"}/>
            <TitleCards title={'Top pics for you'} category={"now_playing"}/>
      </div>
      <Footer/>
    </div>
  )
}

export default Home
