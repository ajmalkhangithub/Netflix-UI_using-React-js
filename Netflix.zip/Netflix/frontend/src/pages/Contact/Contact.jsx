import React from 'react';
import './Contact.css';
import { useSelector, useDispatch } from "react-redux";

const Contact = () => {
  const dispatch = useDispatch();
  const count = useSelector((state) => state.counter);

  return (
    
    <div className='main-contact'>
      <button onClick={() => dispatch({ type: 'Increment' })}>Increment</button>
      <button onClick={() => dispatch({ type: 'Decrement' })}>Decrement</button>
      <button onClick={() => dispatch({ type: 'reset' })}>Reset</button>
      <h2>{count}</h2>
    </div>
  );
};

export default Contact;
