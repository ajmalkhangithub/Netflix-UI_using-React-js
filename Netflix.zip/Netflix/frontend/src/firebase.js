// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";

import { createUserWithEmailAndPassword, getAuth, signInWithEmailAndPassword, signOut } from 'firebase/auth';
import { addDoc, collection, getFirestore } from 'firebase/firestore'
import { getAnalytics } from "firebase/analytics";
import { toast } from "react-toastify";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyBriXeBr4UF8EUyJkYDoMK6lxTIHLA1vAU",
  authDomain: "netflix-fcf63.firebaseapp.com",
  projectId: "netflix-fcf63",
  storageBucket: "netflix-fcf63.firebasestorage.app",
  messagingSenderId: "817978299855",
  appId: "1:817978299855:web:b4ff7a2b598a9c53446eba",
  measurementId: "G-01Q9THQMKY"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth=getAuth(app);

const db=getFirestore(app)
// const analytics = getAnalytics(app);

const signup= async(name,email,password)=>{
try {
    const res=await createUserWithEmailAndPassword(auth,email,password)
    const user=res.user
    await addDoc(collection(db,"user"),{
        uid:user.uid,
        name,
        authProvider:"local",
        email,

    })

    alert("Sign Up Succefully")

} catch (error) {
    console.log(error);
    toast.error(error.code)
}
}


const login= async(email,password)=>{
try {
    await signInWithEmailAndPassword(auth,email,password)
    alert("Login Succefully")
    
} catch (error) {
    console.log(error)
  toast.error(error.code)
}
}

const logout=()=>{
    signOut(auth)
}

export {
    auth,
    db,
    signup,
    login,
    logout
}