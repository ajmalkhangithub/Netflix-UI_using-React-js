import React from 'react'
import './Footer.css'
import yutube_icon from '../../Assets/youtube_icon.png'
import facebook_icon from '../../Assets/facebook_icon.png'
import instegram_icon from '../../Assets/instagram_icon.png'
import twitter_icon from '../../Assets/twitter_icon.png'
const Footer = () => {
  return (
    <div className='footer'>
      <div className="footer-icons">
        <img src={yutube_icon} alt="" />
               <img src={facebook_icon} alt="" />
                      <img src={instegram_icon} alt="" />
                             <img src={twitter_icon} alt="" />
      </div>
      <ul>
        <li>audio Description</li>
        <li>help Center</li>
        <li>Gift Cards</li>
        <li>Media Center</li>
        <li>Investor Relations</li>
        <li>Jobs</li>
        <li>Terms of Use</li>
        <li>Privacy</li>
        <li>Legal Notices</li>
        <li>Contact Us</li>
        <li>Home</li>
        <li>Tv Show</li>
      </ul>
      <p className="copyright-text">2025 reserved </p>
    </div>
  )
}

export default Footer
