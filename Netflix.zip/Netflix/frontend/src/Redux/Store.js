import { configureStore } from '@reduxjs/toolkit'

const counterReducer = (state = 0, action) => {
  switch (action.type) {
    case 'Increment': 
      return state + 1;
    case 'Decrement': 
      return state - 1;
    default: 
      return state=0;
  }
};

export const store = configureStore({
  reducer: {
    // contact: contactReducer,   // contactSlice wali state
    counter: counterReducer    // counter wali state
  }
});

export default store;
